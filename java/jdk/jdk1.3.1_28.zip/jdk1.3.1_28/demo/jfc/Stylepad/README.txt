
To run the Stylepad demo on 1.3:
  java -jar Stylepad.jar

