
To run the Notepad demo on 1.3:
  java -jar Notepad.jar

