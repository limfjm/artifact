The four examples in this directory show how to use some of the
features of the JTable component.

TableExample:
   Uses a JTable to show data from an SQL query input on the command
   line.
TableExample2:
   Is like the previous example, but has a UI for configuring the
   database connection and query.
 TableExample3:
   Is a minimal example showing how to plug a generic sorter into the
   JTable.
TableExample4:
   Uses specialized renderers and editors.

TableExample3 and TableExample4 do not depend on database connectivity
and can be compiled and run in the normal way.

The most interesting example is probably TableExample, which has a
TextArea that can be used as an editor for an SQL expression.  Pressing
the Fetch button sends the expression to the database.  The results are
displayed in the JTable underneath the text area.

To run TableExample and TableExample2, you need to find a driver for
your database and set the environment variable JDBCHOME to a directory
where the driver is installed.  See the following URL for a list of
JDBC drivers provided by third party vendors:

  http://java.sun.com/products/jdbc/drivers.html

Once you find the driver, you can run one of the database examples by
specifying a class path that includes the JDBC classes and the example
classes.

For example, to run TableExample using 1.3 on Solaris:

  java -classpath $(JDBCHOME):TableExample.jar TableExample

