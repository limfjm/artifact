FileChooserDemo demonstrates some of the capabilities of the 
JFileChooser object.  It brings up a window displaying several
configuration controls that allow you to play with the
JFileChooser options dynamically.
 
To run the FileChooserDemo demo on 1.3:
  java -jar FileChooserDemo.jar

