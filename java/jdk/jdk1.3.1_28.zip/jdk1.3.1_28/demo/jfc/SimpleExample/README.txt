SimpleExample is the "Hello, world" of the Swing release.  It brings up
a window displaying a regular button followed by three radio buttons.
The regular button does nothing; it's there for looks alone.  The other
three buttons let you choose the look and feel (L&F) that SimpleExample
uses.

To run the SimpleExample demo on 1.3:

  java -jar SimpleExample.jar

